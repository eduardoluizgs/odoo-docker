# Odoo Sample Module

Este repositório contém um exemplo de módulo Odoo.
